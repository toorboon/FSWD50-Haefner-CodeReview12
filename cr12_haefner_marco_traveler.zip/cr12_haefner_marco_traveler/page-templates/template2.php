<?php /* Template Name: Template*/ ?>

<?php get_header(); ?>

This is the template.php
<h1 class="text-center text-white">The Template</h1>
<?php the_content(); ?>

<?php get_footer(); ?>