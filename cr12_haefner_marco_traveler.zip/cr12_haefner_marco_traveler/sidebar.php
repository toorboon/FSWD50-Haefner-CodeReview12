<div class="col-3 bg-light p-3 rounded d-md-block d-none">
	<?php dynamic_sidebar( 'sidebar' ); ?>
</div>