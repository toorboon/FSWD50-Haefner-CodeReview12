<?php wp_footer(); ?>
<footer id="footer">
  <?php require "nav2.php"; ?>
</footer>
</body>
</html>