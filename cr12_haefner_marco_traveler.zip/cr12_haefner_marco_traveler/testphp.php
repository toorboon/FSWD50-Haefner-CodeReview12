<?php 
$testvariable 
 ?>